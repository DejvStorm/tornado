# -*- coding: utf-8 -*-
import os
import sys
import csv
import xlrd

import numpy as np

from PIL import Image, ImageDraw, ImageFont



# otevre soubor v excelu a vytvori z nej CSV soubory
excel_file = 'data_in/Tornado_ratings.xls'
workbook = xlrd.open_workbook(excel_file)

# kazdy list ulozi do samostatneho csv souboru
for sheet_name in workbook.sheet_names():
    
    print ('XLS to CSV - ' + sheet_name)
    worksheet = workbook.sheet_by_name(sheet_name)
    
    csv_file_full_path = 'data_in/Tornado_ratings_' + sheet_name + '.csv'
    csvfile = open(csv_file_full_path, 'w', encoding="utf-8")
    
    for rownum in range(worksheet.nrows):
        
        row = worksheet.row_values(rownum)
        
        try:
            dod = '{:4d}'.format(int(row[3]))           
        except:
            dod = '    '
            
        try:
            xcoord =  '{:5d}'.format(int(row[5]))
        except:
            xcoord = '     '
            
        ifs_str = str(row[4])
        ifs_del = ifs_str.find('.')
        
        if(ifs_del > -1):
            ifs_str = ifs_str[:ifs_del]        
        
        fin_str = str(row[0]) + ';' + str(row[1]) + ';' +  str(row[2])\
                  + ';' + dod + ';' + ifs_str\
                  + ';' + xcoord + ';' +  str(row[6])
                  
        csvfile.write(fin_str+'\n')
        
    csvfile.close()
    

    
print('all CSV files done - ready to plot PNG diagrams')



files = (
    {"srcfile": '_Hrušky-Hlavní', "out_image": 'hrusky', "name": 'Hrušky - Hlavní street'},
    {"srcfile": '_Moravská Nová Ves', "out_image": 'mornoves', "name": 'Moravská Nová Ves - náměstí'},
    {"srcfile": '_Mikulčice-náves', "out_image": 'mikul_naves', "name": 'Mikulčice - náves'},
    {"srcfile": '_Mikulčice - U školky', "out_image": 'mikul_skolka', "name": 'Mikulčice - U Školky street'},
    {"srcfile": '_Lužice-Důlní', "out_image": 'luzice_dulni', "name": 'Lužice - Důlní street'},
    {"srcfile": '_Panov', "out_image": 'hodonin_panov', "name": 'Hodonín - Pánov'})


licons = (
    {"ic_file": '_building_fall', "object": 'walls or frames'},
    {"ic_file": '_roof_fall', "object": 'roof structure'},
    {"ic_file": '_tiles_fall', "object": 'roof cover'},
    {"ic_file": '_tree_fall', "object": 'trees'},
    {"ic_file": '_powerlines_fall', "object": 'poles and towers'},
    {"ic_file": '_car_roll', "object": 'road vehicles'})


# ulozit data jako jednotlive rezy + kolaz pro srovnani?
all_in_one = True
all_separ = True

save = True



# nastaveni rozmeru apod.
img_w = 1200

icon_size = 50
icons_light = 0
lines_light = 0

licon_size = 40
licons_light = 0

radi = 10
scale = 5/6

img_h = 50 + icon_size * 7

x_coord_offset = 600

if(((x_coord_offset / 50) % 2) == 0):
    evenVodd = 0
else:
    evenVodd = 1


# definice pouzitych pisem
#spath = sys.path[0]
spath = "/home/dave2storm/SOFT_MY/Python/Work/tornado/"

font_picsmt = ImageFont.truetype(os.path.join(spath,"fonts/arialbd.ttf"), 12)
font_picsbt = ImageFont.truetype(os.path.join(spath,"fonts/arialbd.ttf"), 14)
font_pictit = ImageFont.truetype(os.path.join(spath,"fonts/arialbd.ttf"), 18)


# preddefinovani pouzivanych barev
col_f0 = (  0, 215, 130)
col_f1 = (133, 255,   0)
col_f2 = (248, 190,   0)
col_f3 = (245,  31,   0)
col_f4 = (160,   0, 255)

col_ll = (0,0,0)
col_ltext = (0, 0, 0)



# srovnavaci velka kolaz, vytvoreni platna
if(all_in_one == True):
    img_all_h =  100 + img_h * len(files)
    img_all = Image.new(mode="RGB", size=(img_w, img_all_h), color = (255, 255, 255))




# genervani jednotlivych rezu, jejich ukladani do souboru, ale i skladani do srovnavacky
for id_cs in range(len(files)):
    
    file = files[id_cs]
        
    print('CSV to PNG -',file["name"])
    
    
    
    srcfile = "data_in/Tornado_ratings" + file["srcfile"] + ".csv"
    out_image = "imgs_out/0" + str(id_cs+1) + file["out_image"] + ".png"
    
    
    img = Image.new(mode="RGB", size=(img_w, img_h), color = (255, 255, 255))
    draw = ImageDraw.Draw(img)
    
    
    # nadpis a jeho zarovnani
    tittle_text = '(CS n.' + str(id_cs+1) + ')  ' + file["name"]
    
    #tw, th = draw.textsize(tittle_text, font=font_pictit)
    #draw.text((img_w/2 - tw/2, 15), tittle_text, "gray", font=font_pictit)
    draw.text((75, 25), tittle_text, "black", font=font_picsbt)
    
    
    
    # priprava grafu pro kresleni skod
    # - vykresli zaklad osy
    draw.line((100, 50 + icon_size*3, img_w - 50,
               50 + icon_size*3), fill ="black", width = 1)
    
    
    # - popisek osy a jednotky
    draw.text((15, 57 + icon_size*3), 'distance [m]', "black", font=font_picsmt)
    
    # - pomocne slabsi osy pro kazdou ze skod
    for lid in range(3):
        draw.line((100, 50 + icon_size*(0.5 + lid),
                   img_w - 50, 50 + icon_size*(0.5 + lid)), fill = col_ll, width = 1)
    
    for lid in range(3,6):
        draw.line((100, 75 + icon_size*(0.5 + lid),
                   img_w - 50, 75 + icon_size*(0.5 + lid)), fill = col_ll, width = 1)
    
    
    # - kolme cary na ose po 50 metrech
    for i in range(1, 25):
        
        x_line = 100 + i * 50 * scale
        
        draw.line((x_line, 55 + icon_size*3,
                   x_line, 45 + icon_size*3), fill ="black", width = 1)
        
        
        # - popisky po kazdych 100 metrech
        #if((i % 2) == 0):
        if(((i + evenVodd) % 2) == 0):
                    
            w, h = draw.textsize(str(i*50 - x_coord_offset), font=font_picsmt)
            draw.text((x_line - w/2, 57 + icon_size*3), str(i*50 - x_coord_offset), "black", font=font_picsmt)        
            
            for lid in range(3):
                
                ydot = 50 + icon_size*(0.5 + lid)
                draw.ellipse((x_line-2, ydot-2, x_line+2, ydot+2), fill = col_ll)
                
            
            for lid in range(3,6):
                
                ydot = 75 + icon_size*(0.5 + lid)
                draw.ellipse((x_line-2, ydot-2, x_line+2, ydot+2), fill = col_ll)
            
    
    # vsechny typy ikon - klicove casti nazvu souboru ikon 
    icons = [
        '_building_fall',
        '_roof_fall',
        '_tiles_fall',
        '_tree_fall',
        '_powerlines_fall',
        '_car_roll']
    
    # vykresleni ikon do y osy grafu
    for ic_id in range(len(icons)):
        icon = Image.open("icons/icon" + icons[ic_id] + ".png")

        icon_data = np.array(icon)
        r,g,b,a = icon_data.T
        
        icon_repl = (r == 0) & (g == 0) & (b == 0)
        icon_data[..., :-1][icon_repl.T] = (icons_light, icons_light, icons_light)
        
        icon = Image.fromarray(icon_data)
        icon = icon.resize((icon_size,icon_size), Image.ANTIALIAS)
        
        if(ic_id < 3):
            img.paste(icon, (15, 50 + icon_size * ic_id), icon)
        else:
            img.paste(icon, (15, 75 + icon_size * ic_id), icon)
        
        del(icon)
        
    
    
    # priprava slovnikoveho pole pro nacteni dat
    dict_dmg = {
        "ob_type": '',
        "ob_stur": '',
        "ob_dod": -999,
        "ifs": -999,
        "ifs_str": '',
        "x_coord": -999.0
        }
    
    nums_dat = [dict_dmg for y in range(100)]
    
    
    
    # #########################################################################
    # --- sekce cteni dat ze souboru  a priprava na dalsi zpracovani ---
    
    numline = 0
    datline = 0
    
    max_x = 0    
    max_ifs = 0
    
    # otevreni datoveho souboru a nacteni dat do slovnikoveho pole
    fin = open(srcfile, 'r', encoding="utf-8")#, errors='ignore')
    reader = csv.reader(fin, delimiter=';')
    
    
    for row in reader:          
        
        if((row[0] != '') and (numline > 2)):
            #print(row)
            
            try:
                ifs_str = row[4]                
                x_coord = float(row[5])
                
                ob_type = row[1]
                ob_stur = row[2]
                ob_dod  = int(float(row[3]))
                
                ifs = int(ifs_str[:1])
                
                dict_dmg = {
                    "ob_type": ob_type,
                    "ob_stur": ob_stur,
                    "ob_dod": ob_dod,
                    "ifs": ifs,
                    "ifs_str": ifs_str,
                    "x_coord": x_coord
                    }
                
                nums_dat[datline] = dict_dmg
                
                if(x_coord > max_x):
                    max_x = x_coord
                    
                if(ifs > max_ifs):
                    max_ifs = ifs
                
                datline += 1
                #print(row)
            
            except:
                #print(row)
                pass
            
        numline += 1
    
        
    
    # zavreni datoveho souboru
    fin.close() 
    


    # #########################################################################
    # --- centrovani rezu na "stred" tornada ---

    # urceni stredu tornada jednoduchu cestou(vprostred vsech skod)
    #delta_x = x_coord_offset - int(max_x / 2)
    
    
    # urceni stredu tornada jako aritm. prumeru polohy maximalnich skod
    num_top_ifs = 0
    all_top_xs = [0]*50
    
    for idr in range(datline):
                
        datrow = nums_dat[idr]                  
        ifs = int(datrow["ifs"])
        
        
        if(ifs == max_ifs):                                   
            all_top_xs[num_top_ifs] =  float(datrow["x_coord"])
            
            num_top_ifs += 1
         
    all_top_xs = all_top_xs[:num_top_ifs]      
    x_cenmn = int(np.mean(all_top_xs))
    delta_x = x_coord_offset - x_cenmn
   
    x_crect = 100 + (delta_x + x_cenmn) * scale
    #draw.line((x_crect, 50, x_crect, 40 + icon_size*3), fill=(255,200,200), width = 1) 
    #draw.line((x_crect, 70 + icon_size*3, x_crect, img_h - 30), fill=(255,200,200), width = 1) 
    #draw.text((x_crect + 2, img_h - 40), "Mean of max. damage +- sigma", fill=(255,200,200), font=font_picsmt)  
    
    
    std_err = int(np.std(all_top_xs))
    
    x_crect = 100 + (delta_x + x_cenmn + std_err) * scale    
    draw.line((x_crect, 60, x_crect, img_h - 40), fill=(255,150,150), width = 1)  
    
    x_crect = 100 + (delta_x + x_cenmn - std_err) * scale    
    draw.line((x_crect, 60, x_crect, img_h - 40), fill=(255,150,150), width = 1) 

    #print(std_err)       
    
    
    # #########################################################################
    # --- sekce vykreslovani dat do diagramu ---
    
    # vykreslovani dat ze slovnikoveho pole
    for ifsl in range(5):    
        for idr in range(datline):    
            
            datrow = nums_dat[idr]                      
            ifs = int(datrow["ifs"])
                       
            if(ifs == ifsl):
                #print(datrow)
                                
                ob_type = datrow["ob_type"]
                ob_stur = datrow["ob_stur"]
                ob_dod = int(datrow["ob_dod"])
                ifs_str = datrow["ifs_str"]
                
                x_coord = float(datrow["x_coord"]) + delta_x
                
                if(ob_type == 'BN'):
                    y_coord = 50 + icon_size*2.5
                    
                elif(ob_type == 'BR'):
                    y_coord = 50 + icon_size*1.5
                    
                elif(ob_type == 'B'):
                    y_coord = 50 + icon_size*0.5
                    
                elif(ob_type in ['T','TR']):
                    y_coord = 75 + icon_size*3.5
                    
                elif(ob_type in ['P','L']):
                    y_coord = 75 + icon_size*4.5
                
                elif(ob_type == 'V'):
                    y_coord = 75 + icon_size*5.5
                    
                else:
                    print("chybka", datrow)    
                
                x = 100 + x_coord * scale
                
                
                if(ifs == 0):
                    ic_col = col_f0
                    
                elif(ifs == 1):
                    ic_col = col_f1
                    
                elif(ifs == 2):
                    ic_col = col_f2
                    
                elif(ifs == 3):
                    ic_col = col_f3
                    
                elif(ifs == 4):
                    ic_col = col_f4
                
                
                
                draw.ellipse((x-radi, y_coord-radi, x+radi, y_coord+radi), fill=ic_col)
                
                tw, th = draw.textsize(ifs_str, font=font_picsmt)
                draw.text((x-tw/2, y_coord-th/2), ifs_str, "black", font=font_picsmt)
                
                draw.ellipse((x-radi, y_coord-radi, x+radi, y_coord+radi), fill=None, outline="black")
            

    
    
    del(draw)
     
    # This method will show image in any image viewer
    #img.show()
    
    # srovnavaci velka kolaz, pridani rezu
    if(all_in_one == True):
        img_all.paste(img, (0, 25 + img_h * id_cs))
        
    
    if(all_separ == True):  
        img_sep_h =  100 + img_h
        img_sep = Image.new(mode="RGB", size=(img_w, img_sep_h), color = (255, 255, 255))
        
        img_sep.paste(img, (0, 25))
        
        # nadpis a jeho zarovnani na stred, nadpis legendy
        tittle_text = 'Tornado 24.6.2022, South Moravia - damage swath cross section'
        legend_text = 'IF scale ratings based on damaged:'
        
        sep_draw = ImageDraw.Draw(img_sep)
        
        tw, th = sep_draw.textsize(tittle_text, font=font_pictit)
        sep_draw.text((img_w/2 - tw/2, 15), tittle_text, "black", font=font_pictit)
        
        sep_draw.text((75, img_sep_h - 80), legend_text, col_ltext, font=font_picsbt)
        
        

        
        # vykresleni ikon do legendy na konci stranky
        for ic_id in range(len(licons)):
            licon = licons[ic_id]
            icon = Image.open("icons/icon" + licon["ic_file"] + ".png")
            
            icon_data = np.array(icon)
            r,g,b,a = icon_data.T
            
            icon_repl = (r == 0) & (g == 0) & (b == 0)
            icon_data[..., :-1][icon_repl.T] = (licons_light, licons_light, licons_light)
            
            icon = Image.fromarray(icon_data)
            icon = icon.resize((licon_size,licon_size), Image.ANTIALIAS)
            img_sep.paste(icon, (75 + 180 * ic_id, img_sep_h - 60), icon)
            
            del(icon)
            
            sep_draw.text((125 + 180 * ic_id, img_sep_h - 45), licon["object"], col_ltext, font=font_picsmt)
        
        del(sep_draw)
        
        img_sep.save(out_image, "PNG") 
        
        
        del(img)
        del(img_sep)
    
    

# srovnavaci velka kolaz, vytvoreni platna
if(all_in_one == True):
    # nadpis a jeho zarovnani na stred, nadpis legendy
    tittle_text = 'Tornado 24.6.2022, South Moravia - damage swath cross sections'
    legend_text = 'IF scale ratings based on damaged:'
    
    all_draw = ImageDraw.Draw(img_all)
    
    tw, th = all_draw.textsize(tittle_text, font=font_pictit)
    all_draw.text((img_w/2 - tw/2, 15), tittle_text, "black", font=font_pictit)
    
    all_draw.text((75, img_all_h - 80), legend_text, col_ltext, font=font_picsbt)
    
    
    
    
    
    # vykresleni ikon do legendy na konci stranky
    for ic_id in range(len(licons)):
        licon = licons[ic_id]
        icon = Image.open("icons/icon" + licon["ic_file"] + ".png")
        
        icon_data = np.array(icon)
        r,g,b,a = icon_data.T
        
        icon_repl = (r == 0) & (g == 0) & (b == 0)
        icon_data[..., :-1][icon_repl.T] = (licons_light, licons_light, licons_light)
        
        icon = Image.fromarray(icon_data)
        icon = icon.resize((licon_size,licon_size), Image.ANTIALIAS)
        img_all.paste(icon, (75 + 180 * ic_id, img_all_h - 60), icon)
        
        del(icon)
        
        all_draw.text((125 + 180 * ic_id, img_all_h - 45), licon["object"], col_ltext, font=font_picsmt)
    
    del(all_draw)


 
    # ulozeni slouceneho obrazku
    if(save == True):
        img_all.save("imgs_out/all_in_one.png", "PNG")
    else:
        img_all.show()
        
    del(img_all)